for run the program in MPI :
 myprogram.exe path_data_file

the first args will be the full path of data.txt of numbers file.


Please note : you must to execute with only 2 processes,else the program

throw expection error message


** Also must be cude installed on both computers .(CUDA > 9)